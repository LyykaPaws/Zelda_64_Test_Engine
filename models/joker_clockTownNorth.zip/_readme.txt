Ripped by Guy

Legend of Zelda: Majora's Mask 3DS

For The Models Resource:
http://www.models-resource.com

Please note that some models have been slightly edited to restore them to a usable state (normally the eyes) due to the way they're exported from the ripping program.

Textures may be missing as well (ex: eyes blinking texture), as not all textures are exported from ripping program either.